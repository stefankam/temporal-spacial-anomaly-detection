There code contains:
1. a python file, ETH_data_collect_transactions_activity.py, to obtain and preprocess data according to 3.1 in the main text,
2. a python file, TRW_GCN_anomaly_detection.py, to create Figure 1 and 2, and Table 1.
3. a python file, TRW_GCN_anomaly_pattern.py, to create Figure 3.
4. a python file, TRW_prob_sampling.py, to create Figure 4.